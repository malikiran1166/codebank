7 Quick Fix a freeware by LeeLu Soft 2009 v1.0
-----------------------------------------------

There are a lot of excellent Windows comprehensive repairing and fixing tools around the internet.
But there are times when you want just one quick fix for example when you are under a virus attack and you
just want to enable the Task Manager or the Registry Editor so you can fight the virus back, or when some new installation changed your Windows 7 behavior and you want to restore it.
This is the right time to draw 7 Quick Fix with 21 common Windows 7 fixes, only 472kb, portable, small and fast, a must have on every computer !
Note: There can be a problem with the same symptoms as described here, but it happened by a different reason, in this case, 7 Quick Fix, may not solve the problem but also will not harm your computer
Note: If your computer is part of an organizational network, some issues are likely because of the organization group policy, this tool is only for use with personal and private computers !


How to use 7 Quick Fix 
-----------------------
7 Quick Fix is a portable application, There is no install process, just unzip to any folder and run it.

Using 7 Quick Fix is very simple, just run it, and when hovering over a button, it will show the fix information at the bottom information window.
To apply a fix, just click on the button with the relevant fix
Some of the fixes may effect only after a restart or logoff - logon.

Clicking a fix button is safe and will not harm even a proper configured computer !


OS Support
----------
7 Quick Fix was made for Windows 7 and was not tested on any other OS except Windows 7 Ultimat (32bit).


Notes
-----
Very important ! 7 Quick Fix will not remove any virus or mallware !!, it will just enable some of the features that were disabled by the virus or other programs, you still have to take the required steps to remove the virus, but it will for sure help you fight back.
Be aware, if your computer is a part of an organizational network some issues are likely because of the organization group policy, this tool is only for use with personal and private computers !
if you computer is part of an organization network, advice your system administrator before using this tool !


LeeLu Soft Freeware License
---------------------------

Copyright � 2008 by LeeLu Soft <zvika.israeli@gmail.com>. All rights reserved

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Contact:
--------
zvika.israeli@gmail.com 
http://leelusoft.blogspot.com


